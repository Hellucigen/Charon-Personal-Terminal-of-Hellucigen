// Personal Terminal — example plugin: hello-world (panel kind).
//
// Plugins receive a single `pt` host object. The exact API surface is
// documented in docs/PLUGIN_DEVELOPMENT.md, but the shape is roughly:
//
//   pt.notes.list({ template, limit }) → Promise<Note[]>
//   pt.fleeting.capture(body, tags)    → Promise<{ id }>
//   pt.ui.render(rootEl)               → mount your panel into the host
//   pt.event.on(topic, handler)
//   pt.event.publish(topic, payload)
//
// This file is loaded by PluginsService.LoadEntry and executed inside a
// sandboxed iframe. No node/electron globals are exposed.

export default function activate(pt) {
  return {
    title: "Hello, Personal Terminal",

    async mount(rootEl) {
      const recent = await pt.notes.list({ limit: 3 });

      rootEl.innerHTML = `
        <div style="padding:16px;color:#e7eaf3;font:13px Inter,sans-serif">
          <div style="font-family:JetBrains Mono,monospace;
                      letter-spacing:.18em;color:#62e2f5;
                      font-size:11px;margin-bottom:12px">
            ▟█▙ HELLO·WORLD
          </div>
          <p>本插件展示了如何调用 host API:</p>
          <ul style="margin:8px 0 16px 16px;line-height:1.7">
            <li>读取最近的笔记 (找到 ${recent.length} 条)</li>
            <li>抓取一条零碎想法</li>
            <li>订阅事件总线</li>
          </ul>
          <button id="cap"
            style="padding:6px 14px;border:1px solid #62e2f5;
                   color:#62e2f5;background:transparent;font-family:JetBrains Mono,monospace;
                   font-size:11px;cursor:pointer;letter-spacing:.05em">
            CAPTURE THOUGHT
          </button>
        </div>
      `;

      rootEl.querySelector("#cap")?.addEventListener("click", async () => {
        await pt.fleeting.capture(
          "Hello from the example plugin.",
          ["plugin", "demo"]
        );
        pt.toast?.("Captured!");
      });

      pt.event?.on("fascinator.started", () => {
        pt.toast?.("Fascinator started — hello plugin saw it.");
      });
    },

    unmount() {
      // optional teardown
    }
  };
}
