# Plugins · 个人终端插件目录

Drop a plugin folder here and Personal Terminal will pick it up on the next launch (or click `RESCAN` in the Plugins module).

```
~/.personal-terminal/plugins/
  └─ my-plugin/
      ├─ plugin.json     # manifest (required)
      ├─ index.js        # entry (required)
      └─ assets/         # anything else (optional)
```

For the full schema, kinds, permission model, and host API, see [`docs/PLUGIN_DEVELOPMENT.md`](../docs/PLUGIN_DEVELOPMENT.md).

A working starting point lives in `example-plugin/` — copy it, change `id` and `name`, and you have a valid plugin.

## Quick recipe

```bash
cd ~/.personal-terminal/plugins
cp -r ~/where-you-cloned/personal-terminal/plugins/example-plugin my-plugin
# edit plugin.json and index.js
```

Re-open Personal Terminal, navigate to `PLUGINS · 插件中心`, and your plugin will appear in the grid.
