import React, { Suspense, lazy } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { TopBar } from '@/components/TopBar'
import { CommandPalette } from '@/components/CommandPalette'
import { FleetingDrawer } from '@/components/FleetingDrawer'
import { useApp } from '@/store/app'
import { Dashboard } from '@/modules/Dashboard'

// Priority modules — full implementations
const Fascinator = lazy(() => import('@/modules/Fascinator').then(m => ({ default: m.Fascinator })))
const Notes      = lazy(() => import('@/modules/Notes').then(m => ({ default: m.Notes })))
const Todo       = lazy(() => import('@/modules/Todo').then(m => ({ default: m.Todo })))
const Fleeting   = lazy(() => import('@/modules/Fleeting').then(m => ({ default: m.Fleeting })))
const Shortcuts  = lazy(() => import('@/modules/Shortcuts').then(m => ({ default: m.Shortcuts })))
const Bookmarks  = lazy(() => import('@/modules/Bookmarks').then(m => ({ default: m.Bookmarks })))
const Plugins    = lazy(() => import('@/modules/Plugins').then(m => ({ default: m.Plugins })))
const Settings   = lazy(() => import('@/modules/Settings').then(m => ({ default: m.Settings })))

// Stub modules
const Passwords  = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Passwords })))
const Detective  = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Detective })))
const Travel     = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Travel })))
const Institute  = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Institute })))
const Learning   = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Learning })))
const Music      = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Music })))
const Finance    = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Finance })))
const Health     = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Health })))
const Creative   = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Creative })))
const Network    = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Network })))
const Time       = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Time })))
const RPG        = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.RPG })))
const Data       = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Data })))
const Diary      = lazy(() => import('@/modules/Stubs').then(m => ({ default: m.Diary })))

const Fallback: React.FC = () => (
  <div className="flex items-center justify-center h-full">
    <div className="pt-section-label text-text-lo">LOADING ······</div>
  </div>
)

export default function App() {
  const active = useApp(s => s.active)

  let content: React.ReactNode = null
  switch (active) {
    case 'dashboard':  content = <Dashboard />; break
    case 'fascinator': content = <Fascinator />; break
    case 'notes':      content = <Notes />; break
    case 'todo':       content = <Todo />; break
    case 'fleeting':   content = <Fleeting />; break
    case 'shortcuts':  content = <Shortcuts />; break
    case 'bookmarks':  content = <Bookmarks />; break
    case 'passwords':  content = <Passwords />; break
    case 'detective':  content = <Detective />; break
    case 'travel':     content = <Travel />; break
    case 'institute':  content = <Institute />; break
    case 'learning':   content = <Learning />; break
    case 'music':      content = <Music />; break
    case 'finance':    content = <Finance />; break
    case 'health':     content = <Health />; break
    case 'creative':   content = <Creative />; break
    case 'network':    content = <Network />; break
    case 'time':       content = <Time />; break
    case 'rpg':        content = <RPG />; break
    case 'data':       content = <Data />; break
    case 'diary':      content = <Diary />; break
    case 'plugins':    content = <Plugins />; break
    case 'settings':   content = <Settings />; break
    default:           content = <Dashboard />
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-bg text-text-hi">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        <main className="flex-1 overflow-auto pt-stagger">
          <Suspense fallback={<Fallback />}>{content}</Suspense>
        </main>
      </div>
      <CommandPalette />
      <FleetingDrawer />
    </div>
  )
}
