import { create } from "zustand";

export type ModuleID =
  | "dashboard"
  | "fascinator"
  | "notes"
  | "fleeting"
  | "todo"
  | "shortcuts"
  | "bookmarks"
  | "passwords"
  | "detective"
  | "travel"
  | "institute"
  | "learning"
  | "music"
  | "finance"
  | "health"
  | "creative"
  | "network"
  | "time"
  | "rpg"
  | "data"
  | "diary"
  | "plugins"
  | "settings";

export type AccentColor = "cyan" | "magenta" | "violet" | "lime" | "amber" | "rose";

interface AppState {
  active: ModuleID;
  setActive: (m: ModuleID) => void;

  paletteOpen: boolean;
  setPaletteOpen: (b: boolean) => void;

  fleetingDrawerOpen: boolean;
  setFleetingDrawerOpen: (b: boolean) => void;

  sidebarCollapsed: boolean;
  toggleSidebar: () => void;

  accent: AccentColor;
  setAccent: (c: AccentColor) => void;
}

export const useApp = create<AppState>((set) => ({
  active: "dashboard",
  setActive: (m) => set({ active: m }),

  paletteOpen: false,
  setPaletteOpen: (b) => set({ paletteOpen: b }),

  fleetingDrawerOpen: false,
  setFleetingDrawerOpen: (b) => set({ fleetingDrawerOpen: b }),

  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),

  accent: "cyan",
  setAccent: (c) => {
    document.documentElement.setAttribute("data-accent", c);
    set({ accent: c });
  },
}));
