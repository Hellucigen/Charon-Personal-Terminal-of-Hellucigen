import { useApp, type AccentColor } from "@/store/app";
import { MODULE_BY_ID } from "@/lib/modules";
import { Command, Menu } from "lucide-react";
import clsx from "clsx";

const ACCENTS: { id: AccentColor; color: string }[] = [
  { id: "cyan",    color: "#5cf2ff" },
  { id: "magenta", color: "#ff5cd1" },
  { id: "violet",  color: "#a48bff" },
  { id: "lime",    color: "#b6ff5c" },
  { id: "amber",   color: "#ffae5c" },
  { id: "rose",    color: "#ff5c7a" },
];

export default function TopBar() {
  const { active, setPaletteOpen, toggleSidebar, accent, setAccent } = useApp();
  const current = MODULE_BY_ID[active];

  return (
    <header
      className="pt-glass flex items-center justify-between px-4 shrink-0"
      style={{
        height: "var(--pt-topbar-h)",
        borderBottom: "1px solid rgb(var(--pt-edge) / var(--pt-edge-a))",
      }}
    >
      {/* ── left: hamburger + breadcrumb ── */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSidebar}
          className="pt-btn-ghost pt-btn h-7 w-7 p-0 justify-center"
          title="侧栏"
        >
          <Menu size={14} />
        </button>
        <div className="flex items-center gap-2 text-[12.5px]">
          <span className="font-mono text-text-lo">~/</span>
          <span className="text-text-mid">{current.label}</span>
          <span className="text-text-lo">·</span>
          <span className="text-text-lo">{current.hint}</span>
        </div>
      </div>

      {/* ── center: command palette trigger (this is THE chrome hero element) ── */}
      <button
        onClick={() => setPaletteOpen(true)}
        className="group flex items-center gap-2 h-7 px-3 rounded-soft border border-edge bg-black/30 hover:border-white/20 transition"
        style={{ minWidth: 360 }}
      >
        <Command size={12} className="text-text-mid" />
        <span className="text-[12px] text-text-mid flex-1 text-left">搜索 / 命令 …</span>
        <span className="pt-kbd">⌃</span><span className="pt-kbd">K</span>
      </button>

      {/* ── right: accent + status ── */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          {ACCENTS.map(a => (
            <button
              key={a.id}
              onClick={() => setAccent(a.id)}
              title={`accent: ${a.id}`}
              className={clsx(
                "w-3.5 h-3.5 rounded-sharp transition-transform",
                accent === a.id ? "scale-110 ring-1 ring-white/40" : "opacity-60 hover:opacity-100"
              )}
              style={{ background: a.color, boxShadow: accent === a.id ? `0 0 10px ${a.color}80` : undefined }}
            />
          ))}
        </div>
        <div className="pt-divider-vert h-4" />
        <div className="flex items-center gap-1.5">
          <span className="pt-dot live" />
          <span className="text-[10.5px] font-mono text-text-mid">SYS·OK</span>
        </div>
      </div>
    </header>
  );
}
