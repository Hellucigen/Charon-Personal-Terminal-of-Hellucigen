// Package modules — Plugin loader.
//
// At startup we scan the configured plugins dir for subfolders each
// containing a plugin.json manifest. Manifests are surfaced to the frontend
// which then decides whether to mount the plugin's panel/command/block.
//
// Three plugin kinds are supported in this prototype:
//
//   • "panel"       — a full-page module shown in the sidebar
//   • "command"     — a Ctrl+K command palette entry running a JS snippet
//   • "block"       — a custom block type usable inside the Notes editor
//
// The actual execution sandbox lives on the frontend side (a sandboxed
// iframe for HTML/JS plugins). Go-native plugins compiled as .so files
// can be loaded in a future iteration.
package modules

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"

	"personal-terminal/backend/core"
)

type PluginsService struct{}

func NewPluginsService() *PluginsService { return &PluginsService{} }

// List enumerates installed plugins by scanning the plugins dir.
func (s *PluginsService) List() ([]core.PluginManifest, error) {
	cfg := core.GlobalConfig
	if cfg == nil {
		return nil, errors.New("config not initialized")
	}
	entries, err := os.ReadDir(cfg.PluginsDir)
	if err != nil {
		if os.IsNotExist(err) {
			return []core.PluginManifest{}, nil
		}
		return nil, err
	}
	out := []core.PluginManifest{}
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		manifestPath := filepath.Join(cfg.PluginsDir, e.Name(), "plugin.json")
		raw, err := os.ReadFile(manifestPath)
		if err != nil {
			continue
		}
		var m core.PluginManifest
		if err := json.Unmarshal(raw, &m); err != nil {
			continue
		}
		if m.ID == "" {
			m.ID = e.Name()
		}
		out = append(out, m)
	}
	return out, nil
}

// LoadEntry returns the file contents of a plugin's entry script so the
// frontend sandbox can evaluate it. Path traversal is blocked.
func (s *PluginsService) LoadEntry(pluginID, relativePath string) (string, error) {
	cfg := core.GlobalConfig
	if cfg == nil {
		return "", errors.New("config not initialized")
	}
	clean := filepath.Clean(relativePath)
	if filepath.IsAbs(clean) || filepath.HasPrefix(clean, "..") {
		return "", errors.New("invalid entry path")
	}
	full := filepath.Join(cfg.PluginsDir, pluginID, clean)
	rel, err := filepath.Rel(filepath.Join(cfg.PluginsDir, pluginID), full)
	if err != nil || filepath.HasPrefix(rel, "..") {
		return "", errors.New("escape attempt")
	}
	b, err := os.ReadFile(full)
	if err != nil {
		return "", err
	}
	return string(b), nil
}
