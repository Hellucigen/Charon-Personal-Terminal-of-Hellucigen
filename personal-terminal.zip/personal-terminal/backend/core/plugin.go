package core

// PluginManifest describes a single plugin discovered in PluginsDir.
// Plugins are filesystem-resident folders; each must contain plugin.json
// at its root plus the implementation (Go .so, Node script, or HTML view).
type PluginManifest struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Version     string   `json:"version"`
	Author      string   `json:"author"`
	Description string   `json:"description"`
	Kind        string   `json:"kind"`        // "panel" | "command" | "background" | "block"
	Entry       string   `json:"entry"`       // path relative to manifest dir
	Permissions []string `json:"permissions"` // "fs.read" | "fs.write" | "net" | "shell"
	Icon        string   `json:"icon"`        // lucide icon name or "ascii:<chars>"
	// HostMin specifies the minimum Personal Terminal version required.
	HostMin string `json:"host_min"`
}
