package core

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// Config holds the user-tunable settings for the terminal.
// Loaded from ~/.personal-terminal/config.json or via defaults.
type Config struct {
	WorkspaceDir string `json:"workspace_dir"`
	DBPath       string `json:"db_path"`
	MediaDir     string `json:"media_dir"`
	PluginsDir   string `json:"plugins_dir"`

	// External integrations
	FascinatorURL  string `json:"fascinator_url"`
	AnthropicKey   string `json:"anthropic_key"`
	OpenAIKey      string `json:"openai_key"`

	// Theme
	AccentColor string `json:"accent_color"` // cyan | magenta | violet | lime
	Locale      string `json:"locale"`
}

var (
	GlobalConfig *Config
	GlobalStore  any // assigned at startup; typed by importers
	GlobalBus    *EventBus
)

func DefaultConfig() *Config {
	home, _ := os.UserHomeDir()
	root := filepath.Join(home, ".personal-terminal")
	return &Config{
		WorkspaceDir:  root,
		DBPath:        filepath.Join(root, "terminal.db"),
		MediaDir:      filepath.Join(root, "media"),
		PluginsDir:    filepath.Join(root, "plugins"),
		FascinatorURL: "http://127.0.0.1:5000",
		AccentColor:   "cyan",
		Locale:        "zh-CN",
	}
}

func LoadConfig() (*Config, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return nil, err
	}
	root := filepath.Join(home, ".personal-terminal")
	if err := os.MkdirAll(root, 0o755); err != nil {
		return nil, err
	}
	path := filepath.Join(root, "config.json")

	cfg := DefaultConfig()
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			// Persist defaults on first launch.
			_ = saveConfig(path, cfg)
			return cfg, nil
		}
		return nil, err
	}
	if err := json.Unmarshal(data, cfg); err != nil {
		return nil, err
	}
	// Ensure media + plugins dirs exist.
	_ = os.MkdirAll(cfg.MediaDir, 0o755)
	_ = os.MkdirAll(cfg.PluginsDir, 0o755)
	return cfg, nil
}

func saveConfig(path string, c *Config) error {
	data, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0o644)
}

func (c *Config) Save() error {
	home, _ := os.UserHomeDir()
	return saveConfig(filepath.Join(home, ".personal-terminal", "config.json"), c)
}
