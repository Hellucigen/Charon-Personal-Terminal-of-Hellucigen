module personal-terminal

go 1.22

require (
	github.com/wailsapp/wails/v2 v2.9.2
	github.com/mattn/go-sqlite3 v1.14.22
	gopkg.in/yaml.v3 v3.0.1
)
