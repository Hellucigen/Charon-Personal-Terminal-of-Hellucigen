package main

import (
	"context"
	"log"

	"personal-terminal/backend/core"
	"personal-terminal/backend/db"
)

// App is the root struct passed to Wails. Anything bound here becomes
// callable from the frontend as window.go.main.App.<Method>.
type App struct {
	ctx    context.Context
	bus    *core.EventBus
	store  *db.Store
	config *core.Config
}

func NewApp() *App {
	return &App{
		bus: core.NewEventBus(),
	}
}

func (a *App) startup(ctx context.Context) {
	a.ctx = ctx

	cfg, err := core.LoadConfig()
	if err != nil {
		log.Printf("config load fallback to defaults: %v", err)
		cfg = core.DefaultConfig()
	}
	a.config = cfg

	store, err := db.Open(cfg.DBPath)
	if err != nil {
		log.Fatalf("open db: %v", err)
	}
	a.store = store

	if err := store.Migrate(); err != nil {
		log.Fatalf("migrate: %v", err)
	}
	core.GlobalStore = store
	core.GlobalBus = a.bus
	core.GlobalConfig = cfg

	log.Println("personal-terminal started")
}

func (a *App) shutdown(ctx context.Context) {
	if a.store != nil {
		_ = a.store.Close()
	}
}

// Greet is a minimal smoke-test binding the frontend can call to confirm
// the bridge is alive.
func (a *App) Greet() string {
	return "Welcome, operator."
}

// Version exposes the app version to the UI.
func (a *App) Version() string { return "0.1.0" }
